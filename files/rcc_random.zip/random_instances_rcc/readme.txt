﻿# <File format>
# n denote the number of vertices, m the number of arcs and the next m lines stands for the arcs and respectives weights.

n m 
vi vj w_ij
